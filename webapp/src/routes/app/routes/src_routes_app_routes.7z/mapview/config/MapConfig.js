const MAPCONFIG = {

    token : 'pk.eyJ1IjoiYWVyZGVtZWtpbiIsImEiOiJjajhtdGRxb2ExMmE5MnZqczljOXA0MDJhIn0.Fo8sD9jDikhVUu72blwRUA',
    mapstyle : 'mapbox://styles/aerdemekin/cjaksz2udc14a2rqo9lshmsdc',
    defaultViewport : {
        longitude: 29.1,
        latitude: 41.015,
        zoom: 10.2,
        maxZoom: 20,
        minZoom: 10,
        pitch: 33,
        bearing: 14.3
    }

};

module.exports = MAPCONFIG;