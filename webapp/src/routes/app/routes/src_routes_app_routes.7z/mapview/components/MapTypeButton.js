import React , {Component} from 'react';
import FlatButton from 'material-ui/FlatButton';

export default class MapTypeButton extends Component {

    constructor(props){
        super(props);
        this.onClickHandler = this.props.onClick.bind(this);
    }

    render(){
        const {label} = this.props;
        return(
            <FlatButton label={label} onClick={this.onClickHandler}/>
        )
    }
}