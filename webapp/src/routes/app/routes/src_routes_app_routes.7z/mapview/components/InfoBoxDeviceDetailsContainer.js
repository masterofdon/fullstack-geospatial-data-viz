import React , {Component} from 'react';

export default class InfoBoxDeviceDetailsContainer extends Component{
    
    constructor(props){
        super(props);
        this.state = {

        }
    }

    render(){
        const {device} = this.props;
        return(
            
        );
    }
}