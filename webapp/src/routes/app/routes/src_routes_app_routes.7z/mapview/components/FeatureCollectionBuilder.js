const isNull = (r) => (r == null || r == 'undefined')

export function buildFeatureCollectionFromDeviceList(deviceList,sample){
    const fields = [
        'address',
        'administrationStatus',
        'capability',
        'id',
        'lastUpdateDate',
        'name',
        'online'
    ];
    var deviceArray = [];
    var featureCollection = {};
    featureCollection.type = "FeatureCollection";
    featureCollection.crs = {};
    featureCollection.crs.type = "name";
    featureCollection.crs.properties = {};
    featureCollection.crs.properties.name = "urn:ogc:def:crs:OGC:1.3:CRS84";
    featureCollection.features = [];
    var deviceListLength = deviceList.length;
    var fieldsLength = fields.length;
    var i = 0;
    for(;i<deviceListLength;i++){
        var feature = {};
        feature.type = "Feature";
        feature.properties = {};
        feature.geometry = {};
        feature.geometry.type = "Point";
        feature.geometry.coordinates = [];
        for(var j = 0;j < fieldsLength ; j++){
            feature.properties[fields[j]] = deviceList[i][fields[j]];
        }            
        if(!isNull(feature.properties.address.fixedLocation)){
            feature.geometry.coordinates.push(feature.properties.address.fixedLocation.longitude);
            feature.geometry.coordinates.push(feature.properties.address.fixedLocation.latitude);
            
        }else {
            feature.geometry.coordinates = getRandomElementFromArray(sample);
        }
        featureCollection.features.push(feature);
    }
    return featureCollection;

} 

function getRandomElementFromArray(array){
    if (!array)
        return -1;
    var min = 0;
    var max = array.length -1;
    if (max <= 0)
        return array[0];
    var index = parseInt(Math.random() * (max - min) + min, 10);
    
    return array[index];
}