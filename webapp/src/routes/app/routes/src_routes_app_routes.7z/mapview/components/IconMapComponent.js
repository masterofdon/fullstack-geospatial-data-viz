import React, { Component } from 'react';
import TaxiRealtimeDataIconOverlay from './TaxiRealtimeDataIconOverlay';
import { request as Request } from 'd3-request';
import {json as requestJson} from 'd3-request';
import {Popup} from 'react-map-gl';
import Mqtt from 'mqtt';
import ApiStringBuilder from '../data/ApiStringBuilder';
import AuthModule from './AuthModule';
import {buildFeatureCollectionFromDeviceList as BuildFeatureCollectionFromDeviceList} from './FeatureCollectionBuilder';
import {requestDevices as RequestDeviceDetails} from '../data/DataAdapter';
import WebSocketManager from '../data/WebSocketManager';
import PopupContent from './PopupContent';
import {postDevicePropertiesDetails as RequestDevProperties} from '../data/DataAdapter';
import IconComponentDetailsInfoBox from './IconComponentDetailsInfoBox';

const WEB_SOCKET_ADDR = 'ws://10.254.157.165:30000/ws';
const WEB_SOCKET_ADDR2 = 'ws://ion.netas.com.tr:30000/ws';
const isNotNull = r => r != null && r != 'undefined';
const isNull = r => r == null || r === 'undefined'

export default class IconMapComponent extends Component {

    constructor(props) {
        super(props);
        this.state = {
            data : null,
            iconMapping : null,
            showCluster : true,
            popupLatLng : null,
            selectedDevice : null,
            featurecollection : null,
            deviceDetails : null,
            samplelocs : null,
            token : AuthModule.getInstance().getAuthObject('itest').access_token
        };
        this.websocket = null;
        this.deviceList = null;        
        
        this.requestIcons();
        this.requestSampleLocs();
        this.handleClose = this.handleClose.bind(this);
        this.onPopupShow = this.props.onPopupShow;
        this.onPopupHide = this.props.onPopupHide;
        this.lastHovered = null;
        this.onDeviceDetailsUpdated = this.props.onDeviceDetailsUpdated;
        this.initializeWebSocket();                
    }

    connectToWebSocket(){
        return new Promise((resolve,reject) => {
            this.websocket = Mqtt.connect(WEB_SOCKET_ADDR2, {
                protocol: 'wss',
                username : 'itest',
                password : AuthModule.getInstance().getAuthObject('itest').access_token
            });
            resolve();
        });
    }

    initWebSocketHandlers(){
        return new Promise((resolve,reject) => {
            this.websocket.on('message',resolve);
        });
    }

    initializeWebSocket(){
        this.connectToWebSocket.bind(this)()
        .then(function() {
            console.log("Successfully connected to WebSocket...");
            return this.initWebSocketHandlers.bind(this)();
        }.bind(this))
        .then(function(topic, message){
            console.log('Incoming Message:\r\n Topic: ' + topic + '\r\n + Message: ' + message);
            if(this.state.selectedDevice && topic === this.state.selectedDevice.device_id){
                var index = this.indexOfFeature(topic);
                var incMessageObj = JSON.parse(message);
                if(index != -1){
                    var feature = this.state.featureCollection.features[index];
                    if(incMessageObj.latitude != null && incMessageObj.latitude !== 'undefined'){
                        this.state.featureCollection.features[index].geometry.coordinates[1] = incMessageObj.latitude;
                    }
                    if(incMessageObj.longitude != null && incMessageObj.longitude !== 'undefined'){
                        this.state.featureCollection.features[index].geometry.coordinates[0] = incMessageObj.longitude;
                    }
                }
                this.setState({data : this.state.featureCollection.features});
                this.onDeviceDetailsUpdated(incMessageObj);
            }
        }.bind(this));
    }

    requestDeviceListData(){
        RequestDeviceDetails(this.state.token,500,this.deviceDetailsResponseHandler.bind(this));
    }

    deviceDetailsResponseHandler(err, response){
        if(err) {
            throw new Error("Error on Server Request");
        }
        var outer = JSON.parse(response.response);
        this.deviceList = outer._embedded.deviceList;
        var featureCollection = BuildFeatureCollectionFromDeviceList(this.deviceList,this.state.samplelocs);        
        this.setState({
            data : featureCollection.features
        });
        this.setState({featurecollection : featureCollection});
    }
    
    indexOfFeature(device_id){
        var len = this.state.featureCollection.features.length;
        var i;
        for(i = 0; i < len ; i++){
            if(this.state.featureCollection.features[i].properties.name === device_id){
                return i;
            }
        }
        return -1;
    }

    requestIcons(){
        requestJson('example/location-icon-mapping.json', (error, response) => {
            if (!error) {
                this.setState({iconMapping: response});
            }
        });
    }

    sampleLocation(error,response){
        if (!error) {
            this.setState({samplelocs: response});                
            setTimeout(this.requestDeviceListData.bind(this),1000);
        }
    }

    requestSampleLocs(){
        requestJson('example/sample_locs.json', this.sampleLocation.bind(this));
    }

    componentWillUnmount(){
        var deviceListLength = this.deviceList.length;
        var i = 0;
        if(this.state.selectedDevice != null && this.state.selectedDevice !== 'undefined'){
            this.websocket.unsubscribe(this.state.selectedDevice.device_id);
            this.setState({
                popupLatLng : null
            });   
        }
    }

    _onItemHover(item){
        var {viewport} = this.props;
        const z = Math.floor(viewport.zoom);
        var hoveredPoints = item.object && item.object.zoomLevels[z].points;
        if(hoveredPoints == null){
            this.lastHovered = null;
            this.hideToolTip();
            return;
        } else if(isNull(this.lastHovered)){
           this.lastHovered = item.object.properties.id;
           this.showToolTip(item);
        }
    }

    hideToolTip(){
        console.log("HIDE HOVER");
        this.setState({popupLatLng : null, popupContent : null});  
    }

    showToolTip(item){
        console.log("SHOW HOVER");
        if(isNull(item)){
            return;
        }
        var {viewport} = this.props;
        const z = Math.floor(viewport.zoom);
        var items = item.object.zoomLevels[z].points;
        var object = {};
        object.popupLatLng = [item.lngLat[0],item.lngLat[1]];
        object.content = [];
        for(var i=0;i < items.length;i++){
            object.content.push(items[i].properties);
        }
        this.setState({popupLatLng : object.popupLatLng, popupContent : object.content});  
    }

    _onItemClicked(item){
    }

    onDeviceSelected(event){
        var devicename = event.currentTarget.getAttribute('data-deviceid');
        //Find the device details.
        var i = 0;
        var len = this.state.featurecollection.features.length;

        for(;i < len;i++){
            if(this.state.featurecollection.features[i].properties.name === devicename){
                //this.setState({selectedDetailsItem : this.state.featurecollection.features[i]});
                this.requestDeviceDetails(this.state.featurecollection.features[i]);
                return;
            }
        }
    }

    requestDeviceDetails(device){
        var apistrbuilder = new ApiStringBuilder();
        var queryStr = apistrbuilder
            .api('1.0')
            .devices(device.properties.id)
            .details()
            .parameters({
                access_token : this.state.token
            })
            .toString();
        Request(queryStr)
        .header("Content-Type", "application/json")
        .header('Authorization', this.state.token)
        .get(this._deviceDetailsResponseHandler.bind(this));   
    }

    _deviceDetailsResponseHandler(error, response){
        var data = (response.response) ? JSON.parse(response.response) : null;
        this._requestDevicePropertiesDetails(data);
    }

    _requestDevicePropertiesDetails(devicedetails){
        RequestDevProperties(devicedetails.device.name,this.state.token,function(error,response){
            if(error){
                throw new Error("Error while _requestDevicePropertiesDetails");
            }
            var result = JSON.parse(response.response)._embedded.result[0];
            this.setState({
                deviceDetails : result.data
            });
            this.websocket.subscribe(result.data.device_id, function(e,r){
                console.log('Subscription successful');
            });
        }.bind(this));
    }

    handleClose(){
        this.setState({
            deviceDetails : null
        });
    }

    render() {
        const {data,iconMapping,showCluster, popupLatLng, popupContent, deviceDetails} = this.state;
        var {selectedDevice, viewport} = this.props;
        if(isNull(this.state.selectedDevice)){
            this.state.selectedDevice = selectedDevice;
            if(isNotNull(this.state.selectedDevice)){
                console.log("Subscribing to: " + this.state.selectedDevice.device_id);
                
            }
        }        
        else if(isNotNull(selectedDevice) && this.state.selectedDevice.device_id != selectedDevice.device_id){
            console.log("UnSubscribing to: " + this.state.selectedDevice.device_id);
            this.websocket.unsubscribe(this.state.selectedDevice.device_id);
        }
        return (            
            <div>
                {data && <TaxiRealtimeDataIconOverlay
                    viewport={viewport}
                    data={data}
                    iconAtlas="assets/images/location-icon-atlas.png"
                    iconMapping={iconMapping}
                    showCluster={showCluster}
                    onHover={this._onItemHover.bind(this)}
                    onClick={this._onItemClicked.bind(this)}
                >       
                </TaxiRealtimeDataIconOverlay>}
                {deviceDetails && <IconComponentDetailsInfoBox devicedetails={deviceDetails} captureScroll={true} onClose={this.handleClose}/>}
                {popupContent && <PopupContent lngLat={popupLatLng} anchor={"top"} devices={popupContent} onItemSelected={this.onDeviceSelected.bind(this)}/>}
            </div>
        );
    }

}

function getRandomElementFromArray(array){
    if (!array)
        return -1;
    var min = 0;
    var max = array.length -1;
    if (max <= 0)
        return array[0];
    var index = parseInt(Math.random() * (max - min) + min, 10);
    
    return array[index];
}