import React , {Component} from 'react';
import MapContainer from './MapContainer';
import MapConfig from '../config/MapConfig';
import AuthModule from './AuthModule';
import MapTypeController from './MapTypeController';
import MapTypeButton from './MapTypeButton';

class MapView extends Component{
    constructor(props){
        super(props);
        this.state = {
            maptype : 'heatmap'
        }
        this.onHeatMapClicked = this.onHeatMapClicked.bind(this);
        this.onIconsClicked = this.onIconsClicked.bind(this);
    }

    authenticate(){
        return new Promise(function(resolve,reject){
            AuthModule.getInstance().authenticateWithUserPass('itest','1234',resolve);
        }.bind(this));
    }

    onMapStateChange(){

    }

    onHeatMapClicked(){
        this.setState({
            maptype : 'heatmap'
        });
    }

    onIconsClicked(){
        this.setState({
            maptype : 'taxiicon'
        });
    }

    render(){

        return(
                <div className={"container-fluid no-breadcrumbs page-mapview"}>
                    <MapTypeController >
                        <MapTypeButton label={'HeatMap'} onClick={this.onHeatMapClicked}/>
                        <MapTypeButton label={'Icons'} onClick={this.onIconsClicked} />
                    </MapTypeController>
                    <MapContainer onMapStateChange={this.onMapStateChange.bind(this)} maptype={this.state.maptype} mapstyle={MapConfig.mapstyle}/>
                </div>
        );
    }
}

module.exports = MapView;