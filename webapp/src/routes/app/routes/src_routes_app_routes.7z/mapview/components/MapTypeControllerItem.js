import React, {Component} from 'react';
import FlatButton from 'material-ui/FlatButton';

class MapTypeControllerItem extends Component{

    constructor(props){
        super(props);
    }


    render(){
        
    }
}