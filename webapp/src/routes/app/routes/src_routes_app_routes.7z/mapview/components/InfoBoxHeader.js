import React, {Component} from 'react';
import IconButton from 'material-ui/IconButton';
import {red500, yellow500, blue500} from 'material-ui/styles/colors';

export default class InfoBoxHeader extends Component {

    constructor(props){
        super(props);
        this.state = {
            displaytext : this.props.displaytext
        }
        this.onHeaderChange = this.props.onHeaderChange;        
    }

    render() {
        var textStyle = {
            textAlign : "center"
        };
        const iconStyles = {
            marginRight: 15,
            cursor : 'pointer',
            color : 'red'
        };
        const buttonStyle = {            
            float : 'right',
            top : '-10px'
        }
        return (
            <div className={"infobox-header-container bg-color-primary"}>
                <span>{this.state.displaytext}</span>
            <IconButton
                style={buttonStyle}
                iconClassName="material-icons"
                iconStyle={iconStyles}
                onClick={this.props.onClose.bind(this)}
                tooltip="Close"
                >close
            </IconButton>
            </div>
        );
    }

}

