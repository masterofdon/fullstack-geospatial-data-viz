import React ,{Component} from 'react';
import SystemMetricsContainer from './SystemMetricsContainer';
import EngagementStats from './EngagementStats';
import BoxContainer from './BoxContainer';
import BenchmarkChart from './BenchmarkChart';
import SystemMetric from '../data/SystemMetric';


let metrics = [];
metrics.push(new SystemMetric('3.2 K','Taksi'));
metrics.push(new SystemMetric('13 M','Olcum Sayisi'));
metrics.push(new SystemMetric('187 K Saat','Olcum Suresi'));
metrics.push(new SystemMetric('200 K Saat','Online ve Ayakta'));

class Engagement extends Component{
    constructor(props){
        super(props);
    }

    render(){
        return(
            <div className="box box-default">
                <div className="box-body">
                    <div className="row">
                        <BoxContainer size={8} title={"Etkilesim"}>
                            <SystemMetricsContainer metrics={metrics} />
                            <EngagementStats />
                        </BoxContainer>
                        <BoxContainer size={4} title={'Esik Degerler'}>
                            <BenchmarkChart />
                        </BoxContainer>
                    </div>
                </div>
            </div>
        );
    }
}

module.exports = Engagement;